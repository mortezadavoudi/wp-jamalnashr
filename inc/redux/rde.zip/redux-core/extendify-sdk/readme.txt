=== Extendify Sdk ===
Requires at least: 5.4
Stable tag: 13.4
Requires PHP: 5.6
Tested up to: 5.7.0
